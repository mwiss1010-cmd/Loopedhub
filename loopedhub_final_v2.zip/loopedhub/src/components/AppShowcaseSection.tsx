import appScreen1 from "@/assets/app-screen-1.png";
import appScreen2 from "@/assets/app-screen-2.png";
import { Smartphone, Download } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AppShowcaseSection() {
  const androidDownloadUrl = "https://www.mediafire.com/file/7hkwum5wm589v7l/looped.apk/file";

  return (
    <section className="py-24 bg-eco-surface overflow-hidden">
      <div className="mx-auto max-w-7xl px-6 grid gap-12 lg:grid-cols-2 lg:items-center">
        <div>
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">The App</span>
          <h2 className="mt-3 text-3xl font-bold sm:text-4xl">
            Your Recycling Companion, <span className="text-gradient-eco">In Your Pocket</span>
          </h2>
          <p className="mt-4 text-muted-foreground text-lg leading-relaxed">
            Track your points, view leaderboards, complete challenges, and redeem rewards — all from the Looped mobile app. Designed for students, loved by educators.
          </p>

          <div className="mt-8 flex flex-col gap-4">
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <Smartphone className="h-5 w-5 text-primary" />
              Available on iOS and Android
            </div>
            
            <div className="mt-4 flex flex-wrap gap-4">
              <Button variant="outline" className="h-14 px-6 rounded-xl border-2 flex gap-3 items-center" asChild>
                <a href={androidDownloadUrl} target="_blank" rel="noopener noreferrer">
                  <Download className="h-6 w-6 text-primary" />
                  <div className="text-left">
                    <span className="block text-xs text-muted-foreground">Download for</span>
                    <span className="block font-semibold text-foreground">Android (APK)</span>
                  </div>
                </a>
              </Button>

              <div className="flex h-14 items-center gap-3 rounded-xl border-2 border-border bg-card px-5 text-sm font-medium text-muted-foreground opacity-60">
                <svg className="h-7 w-7" viewBox="0 0 24 24" fill="currentColor"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>
                <div className="text-left">
                  <span className="block text-xs text-muted-foreground">Coming Soon on</span>
                  <span className="block font-semibold text-foreground">App Store</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-center">
          <div className="flex items-center gap-8">
            <div className="animate-float-delayed">
              <img
                src={appScreen1}
                alt="Looped app screen 1"
                loading="lazy"
                width={260}
                height={520}
                className="w-48 sm:w-56 rounded-2xl shadow-xl border border-border/30"
              />
            </div>
            <div className="animate-float">
              <img
                src={appScreen2}
                alt="Looped app screen 2"
                loading="lazy"
                width={260}
                height={520}
                className="w-48 sm:w-56 rounded-2xl shadow-xl border border-border/30"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
