import { ShieldCheck, Globe, Users, Leaf } from "lucide-react";

const pillars = [
  {
    icon: Leaf,
    title: "Environmental Development",
    desc: "Achieving harmony between economic growth and environmental protection.",
    color: "text-eco-green",
    bg: "bg-eco-green/10",
  },
  {
    icon: Users,
    title: "Human Development",
    desc: "Empowering the next generation of eco-conscious leaders through education.",
    color: "text-eco-blue",
    bg: "bg-eco-blue/10",
  },
  {
    icon: Globe,
    title: "Sustainable Future",
    desc: "Building a bridge between the present and a greener 2030 for Qatar.",
    color: "text-eco-amber",
    bg: "bg-eco-amber/10",
  },
];

export default function QatarVisionSection() {
  return (
    <section id="qatar-vision" className="relative py-24 overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 left-0 w-full h-full bg-eco-surface/30 -z-10" />
      <div className="absolute -top-24 -left-24 w-64 h-64 rounded-full bg-primary/5 blur-3xl" />
      
      <div className="mx-auto max-w-7xl px-6">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/2">
            <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary mb-6">
              <ShieldCheck className="h-4 w-4" />
              Aligned with Qatar National Vision 2030
            </div>
            <h2 className="text-3xl font-bold sm:text-4xl lg:text-5xl leading-tight">
              Driving <span className="text-gradient-eco">Sustainability</span> in Line with Qatar's 2030 Vision
            </h2>
            <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
              Looped is more than just a recycling app. We are a dedicated partner in Qatar's journey toward 
              environmental excellence. By gamifying sustainability in schools, we directly contribute to 
              the Environmental and Human Development pillars of the National Vision.
            </p>
            
            <div className="mt-10 space-y-6">
              {pillars.map((pillar, i) => (
                <div key={i} className="flex items-start gap-4 group">
                  <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${pillar.bg} ${pillar.color} transition-transform group-hover:scale-110`}>
                    <pillar.icon className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold">{pillar.title}</h3>
                    <p className="text-muted-foreground">{pillar.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="lg:w-1/2 relative">
            <div className="aspect-square rounded-3xl bg-gradient-to-br from-primary/20 to-eco-blue/20 p-8 flex items-center justify-center relative overflow-hidden">
              {/* Decorative circles */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] border border-primary/10 rounded-full animate-pulse" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90%] h-[90%] border border-primary/20 rounded-full" />
              
              <div className="relative z-10 text-center p-8 bg-background/80 backdrop-blur-sm rounded-2xl shadow-xl border border-border max-w-sm animate-float">
                <blockquote className="text-xl font-medium italic text-foreground">
                  "The Qatar National Vision 2030 builds a bridge between the present and the future... in which nature and man are in harmony."
                </blockquote>
                <cite className="mt-4 block text-sm font-bold text-primary not-italic">
                  — His Highness the Amir
                </cite>
              </div>
            </div>
            
            {/* Floating badges */}
            <div className="absolute -top-6 -right-6 bg-white dark:bg-slate-900 shadow-lg rounded-2xl p-4 border border-border animate-float-delayed">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-eco-green/20 flex items-center justify-center text-eco-green">
                  <Leaf className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-medium">Environmental Pillar</p>
                  <p className="text-sm font-bold">100% Aligned</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
