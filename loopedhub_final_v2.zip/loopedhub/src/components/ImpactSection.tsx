import { Leaf, Recycle, Brain, Heart, Flame } from "lucide-react";

const benefits = [
  { icon: Recycle, title: "Reduced Littering", desc: "Cleaner hallways, playgrounds, and cafeterias with visible results." },
  { icon: Leaf, title: "Higher Recycling Rates", desc: "Schools using gamification see up to 3× more recycling participation." },
  { icon: Brain, title: "Environmental Awareness", desc: "Students develop lasting eco-conscious habits they carry into adulthood." },
  { icon: Heart, title: "Positive School Culture", desc: "Shared goals build community spirit and collective responsibility." },
  { icon: Flame, title: "Healthy Competition", desc: "Friendly rivalry between classes and schools drives engagement." },
];

export default function ImpactSection() {
  return (
    <section id="impact" className="py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">Impact</span>
          <h2 className="mt-3 text-3xl font-bold sm:text-4xl">
            Real Change, <span className="text-gradient-eco">Real Results</span>
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">
            Looped doesn't just gamify recycling — it transforms school culture and builds eco-leaders.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {benefits.map((b, i) => (
            <div
              key={i}
              className="flex items-start gap-4 rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-md"
            >
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <b.icon className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-base font-bold">{b.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground leading-relaxed">{b.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}