import { GraduationCap, Palette, Ticket } from "lucide-react";

const categories = [
  {
    icon: GraduationCap,
    title: "School Rewards",
    items: ["Field trips & excursions", "Certificates of achievement", "Extra free time / study hall passes", "Priority lunch seating"],
    gradient: "gradient-eco",
  },
  {
    icon: Palette,
    title: "Digital Rewards",
    items: ["Exclusive avatar skins", "App theme unlocks", "Animated profile badges", "Custom recycling bin stickers"],
    gradient: "bg-eco-blue",
  },
  {
    icon: Ticket,
    title: "Prize Rewards",
    items: ["Sticker packs & merch", "Cafeteria vouchers", "Gift cards & coupons", "Eco-friendly product kits"],
    gradient: "gradient-amber",
  },
];

export default function RewardsSection() {
  return (
    <section id="rewards" className="py-24 bg-eco-surface">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">Rewards</span>
          <h2 className="mt-3 text-3xl font-bold sm:text-4xl">
            Recycle More, <span className="text-gradient-eco">Earn More</span>
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">
            From real-world prizes to digital collectibles, there's always something worth recycling for.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-3">
          {categories.map((c, i) => (
            <div key={i} className="rounded-2xl border border-border bg-card p-8 transition-all hover:shadow-lg">
              <div className={`flex h-14 w-14 items-center justify-center rounded-xl ${c.gradient} text-primary-foreground`}>
                <c.icon className="h-7 w-7" />
              </div>
              <h3 className="mt-5 text-xl font-bold">{c.title}</h3>
              <ul className="mt-4 space-y-3">
                {c.items.map((item, j) => (
                  <li key={j} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span className="h-1.5 w-1.5 rounded-full bg-primary shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}