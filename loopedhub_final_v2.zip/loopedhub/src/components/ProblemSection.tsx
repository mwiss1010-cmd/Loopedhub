import { AlertTriangle, TrendingDown, Trash2, Users } from "lucide-react";

const stats = [
  { icon: Trash2, value: "70%", label: "of school waste isn't recycled properly", color: "text-destructive" },
  { icon: TrendingDown, value: "5%", label: "of students actively participate in recycling", color: "text-eco-blue" },
  { icon: AlertTriangle, value: "80%", label: "of recyclable materials end up in landfills", color: "text-eco-amber" },
  { icon: Users, value: "0", label: "incentives exist for students to recycle", color: "text-primary" },
];

export default function ProblemSection() {
  return (
    <section id="problem" className="py-24 bg-eco-surface">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">The Problem</span>
          <h2 className="mt-3 text-3xl font-bold sm:text-4xl">
            Schools Are Losing the Recycling Battle
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">
            Despite growing environmental awareness, recycling participation in schools remains alarmingly low. Students lack motivation, education, and incentives.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((s, i) => (
            <div
              key={i}
              className={`animate-slide-up animation-delay-${(i + 1) * 100} rounded-2xl bg-card p-8 shadow-sm border border-border text-center hover:shadow-md transition-shadow`}
            >
              <s.icon className={`mx-auto h-10 w-10 ${s.color}`} />
              <p className={`mt-4 text-4xl font-extrabold ${s.color}`}>{s.value}</p>
              <p className="mt-2 text-sm text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}