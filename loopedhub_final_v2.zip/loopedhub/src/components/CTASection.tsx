import { Button } from "@/components/ui/button";
import { ArrowRight, Recycle } from "lucide-react";

export default function CTASection() {
  return (
    <section id="cta" className="py-24">
      <div className="mx-auto max-w-4xl px-6 text-center">
        <div className="rounded-3xl gradient-eco px-8 py-16 sm:px-16 relative overflow-hidden">
          {/* Background decoration */}
          <div className="absolute top-0 right-0 h-64 w-64 rounded-full bg-primary-foreground/10 -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 h-48 w-48 rounded-full bg-primary-foreground/10 translate-y-1/2 -translate-x-1/2" />

          <div className="relative">
            <Recycle className="mx-auto h-12 w-12 text-primary-foreground/80 mb-6" />
            <h2 className="text-3xl font-bold text-primary-foreground sm:text-4xl">
              Ready to Join the Movement?
            </h2>
            <p className="mt-4 text-lg text-primary-foreground/80 max-w-xl mx-auto">
              Bring Looped to your school and watch recycling participation soar. It's free to get started.
            </p>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
              <Button
                size="xl"
                className="bg-background text-primary hover:bg-background/90 font-bold shadow-lg transition-transform hover:scale-105"
              >
                Bring Looped to Your School <ArrowRight className="ml-1 h-5 w-5" />
              </Button>
              <Button
                size="xl"
                variant="outline"
                className="border-2 border-primary-foreground/40 bg-transparent text-primary-foreground hover:bg-primary-foreground/10 font-bold"
                asChild
              >
                <a href="mailto:m_wiss0125@hotmail.com">Contact Us</a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}