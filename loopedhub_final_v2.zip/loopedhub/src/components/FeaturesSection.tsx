import { Star, Award, CalendarCheck, TrendingUp, Trophy, Swords, Gift, Users } from "lucide-react";

const features = [
  { icon: Star, title: "Points System", desc: "Earn points for every correct recycle — watch your total climb." },
  { icon: Award, title: "Badges & Achievements", desc: "Unlock unique badges as you hit milestones and master recycling." },
  { icon: CalendarCheck, title: "Daily Challenges", desc: "Complete fun daily tasks to earn bonus XP and streak rewards." },
  { icon: TrendingUp, title: "Level Progression", desc: "Advance through levels from Rookie Recycler to Eco Legend." },
  { icon: Trophy, title: "Leaderboards", desc: "See how you rank against classmates, classes, and schools." },
  { icon: Swords, title: "Weekly Tournaments", desc: "Compete in themed weekly events for exclusive prizes." },
  { icon: Gift, title: "Rewards Store", desc: "Spend points on school perks, digital items, and real prizes." },
  { icon: Users, title: "Social & Friends", desc: "Add friends, form teams, and challenge each other to recycle more." },
];

export default function FeaturesSection() {
  return (
    <section id="features" className="py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">App Features</span>
          <h2 className="mt-3 text-3xl font-bold sm:text-4xl">
            Everything You Need to <span className="text-gradient-eco">Stay Motivated</span>
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">
            The Looped app is packed with features designed to keep recycling exciting every single day.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f, i) => (
            <div
              key={i}
              className="group rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-lg hover:border-primary/30 hover:-translate-y-1"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:gradient-eco group-hover:text-primary-foreground">
                <f.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-base font-bold">{f.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}