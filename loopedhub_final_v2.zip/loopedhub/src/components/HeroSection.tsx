import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, Download } from "lucide-react";
import heroImg from "@/assets/hero-illustration.png";

export default function HeroSection() {
  const androidDownloadUrl = "https://www.mediafire.com/file/7hkwum5wm589v7l/looped.apk/file"; 

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 gradient-eco-light opacity-60" />
      <div className="absolute -top-40 -right-40 h-96 w-96 rounded-full bg-primary/10 blur-3xl" />
      <div className="absolute -bottom-40 -left-40 h-96 w-96 rounded-full bg-eco-blue/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-6 py-32 grid gap-12 lg:grid-cols-2 lg:items-center">
        <div className="animate-slide-up">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
            <Sparkles className="h-4 w-4" />
            Gamified Recycling for Schools
          </div>
          <h1 className="text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl lg:text-7xl">
            Turn Recycling{" "}
            <span className="text-gradient-eco">Into a Game</span>
          </h1>
          <p className="mt-6 max-w-lg text-lg text-muted-foreground leading-relaxed">
            Looped makes recycling fun, competitive, and rewarding for high school students.
            Tap, sort, earn points, and climb the leaderboard — <strong>saving the planet one toss at a time.</strong>
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <Button variant="hero" size="xl" asChild>
              <a href={androidDownloadUrl} target="_blank" rel="noopener noreferrer">
                Download Android <Download className="ml-2 h-5 w-5" />
              </a>
            </Button>
            <Button variant="heroOutline" size="xl" asChild>
              <a href="#solution">Learn More</a>
            </Button>
          </div>
        </div>

        <div className="relative flex items-center justify-center animate-slide-up animation-delay-200">
          <div className="animate-float">
            <img
              src={heroImg}
              alt="Students interacting with smart recycling bins"
              width={1024}
              height={768}
              className="w-full max-w-lg drop-shadow-xl"
            />
          </div>
          {/* Floating badges */}
          <div className="absolute -top-4 right-8 animate-float-delayed rounded-xl bg-background shadow-lg px-4 py-2 text-sm font-bold text-primary">
            +10 pts ♻️
          </div>
          <div className="absolute bottom-8 -left-4 animate-float rounded-xl bg-background shadow-lg px-4 py-2 text-sm font-bold text-eco-amber">
            🏆 Level Up!
          </div>
        </div>
      </div>
    </section>
  );
}
