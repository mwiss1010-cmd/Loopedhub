import { CreditCard, Trash2, Zap, Gift } from "lucide-react";

const steps = [
  { icon: CreditCard, step: "01", title: "Tap Your Card", desc: "Tap your student ID or Looped card on the smart bin's reader to begin." },
  { icon: Trash2, step: "02", title: "Dispose Correctly", desc: "Sort your waste into the correct compartment — the bin guides you." },
  { icon: Zap, step: "03", title: "Earn Points", desc: "Receive instant points and XP for every successful recycle." },
  { icon: Gift, step: "04", title: "Redeem Rewards", desc: "Trade your points for school rewards, digital items, and prizes." },
];

export default function HowItWorksSection() {
  return (
    <section id="how-it-works" className="py-24 bg-eco-surface">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">How It Works</span>
          <h2 className="mt-3 text-3xl font-bold sm:text-4xl">Four Simple Steps</h2>
          <p className="mt-4 text-muted-foreground text-lg">
            Getting started with Looped takes seconds. Here's how the magic happens.
          </p>
        </div>

        <div className="relative grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {/* Connector line (desktop) */}
          <div className="absolute top-16 left-[12.5%] right-[12.5%] hidden h-0.5 bg-border lg:block" />

          {steps.map((s, i) => (
            <div key={i} className="relative text-center">
              <div className="relative z-10 mx-auto flex h-16 w-16 items-center justify-center rounded-full gradient-eco text-primary-foreground font-bold text-lg shadow-lg animate-pulse-glow">
                <s.icon className="h-7 w-7" />
              </div>
              <span className="mt-4 block text-xs font-bold uppercase tracking-widest text-primary">
                Step {s.step}
              </span>
              <h3 className="mt-2 text-lg font-bold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
