import { CreditCard, Cpu, Trophy, Gamepad2 } from "lucide-react";

const pillars = [
  { icon: Cpu, title: "Smart Bins", desc: "Sensor-equipped recycling bins that detect and sort waste automatically." },
  { icon: CreditCard, title: "Card Interaction", desc: "Tap your card on the bin to log your recycling and earn instant points." },
  { icon: Trophy, title: "Points System", desc: "Accumulate points for every correct disposal. Compete with classmates." },
  { icon: Gamepad2, title: "Gamified XP", desc: "Level up, unlock badges, complete daily challenges and dominate tournaments." },
];

export default function SolutionSection() {
  return (
    <section id="solution" className="py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">The Solution</span>
          <h2 className="mt-3 text-3xl font-bold sm:text-4xl">
            Meet <span className="text-gradient-eco">Looped</span>
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">
            A gamified recycling ecosystem that combines smart hardware, a mobile app, and game mechanics to turn every student into an eco-champion.
          </p>
        </div>

        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {pillars.map((p, i) => (
            <div
              key={i}
              className="group rounded-2xl border border-border bg-card p-8 text-center transition-all hover:shadow-lg hover:-translate-y-1"
            >
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-xl gradient-eco text-primary-foreground transition-transform group-hover:scale-110">
                <p.icon className="h-7 w-7" />
              </div>
              <h3 className="mt-5 text-lg font-bold">{p.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
