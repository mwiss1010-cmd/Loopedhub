import { createFileRoute } from "@tanstack/react-router";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import ProblemSection from "@/components/ProblemSection";
import SolutionSection from "@/components/SolutionSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import FeaturesSection from "@/components/FeaturesSection";
import RewardsSection from "@/components/RewardsSection";
import ImpactSection from "@/components/ImpactSection";
import AppShowcaseSection from "@/components/AppShowcaseSection";
import QatarVisionSection from "@/components/QatarVisionSection";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Looped — Gamified Recycling for Schools" },
      { name: "description", content: "Turn recycling into a game. Looped uses smart bins, a mobile app, and gamification to make recycling fun and competitive for high school students." },
      { property: "og:title", content: "Looped — Gamified Recycling for Schools" },
      { property: "og:description", content: "Turn recycling into a game with smart bins, points, leaderboards, and rewards." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <HeroSection />
      <ProblemSection />
      <SolutionSection />
      <HowItWorksSection />
      <FeaturesSection />
      <RewardsSection />
      <ImpactSection />
      <QatarVisionSection />
      <AppShowcaseSection />
      <CTASection />
      <Footer />
    </div>
  );
}
